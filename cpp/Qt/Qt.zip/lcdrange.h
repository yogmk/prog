# ifndef LCDRANGE_H
# define LCDRANGE_H

# include <QWidget>


class QSlider;

class LCDRange : public QWidget
{
    Q_OBJECT

public:
    LCDRange (QWidget* p=0);
    int value() const;

public slots:
    void setValue(int v);

signals:
    void valueChanged (int newVal);

private:
    QSlider* sld;
};
        
# endif
