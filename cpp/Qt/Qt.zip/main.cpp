# include <QApplication>
# include <QWidget>
# include <QFont>
# include <QPushButton>
# include <QGridLayout>

# include "lcdrange.h"


class mywidget: public QWidget
{
    public:
        mywidget (QWidget* p=0);
};

mywidget::mywidget (QWidget* p) : QWidget (p)
{
    QPushButton* b = new QPushButton(tr("quit"));
    b -> setFont (QFont("DejaVu San mono", 14, QFont::Normal));
    connect (b, SIGNAL(clicked()), qApp, SLOT(quit()));

    QGridLayout* grid = new QGridLayout;
    LCDRange* prevLcd = 0;

    for (int row=0; row<3; ++row)
    {
        for(int col=0; col < 3; ++col)
	{
	    LCDRange* lcd = new LCDRange;
	    grid->addWidget (lcd, row, col);
	    if (prevLcd)
	        connect (lcd, SIGNAL(valueChanged(int)), prevLcd, SLOT(setValue(int)));
	    prevLcd = lcd;
	}
    }

    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget (b);
    layout->addLayout (grid);
    setLayout(layout);
}

int
main (int c, char** v)
{
    QApplication a(c, v);
    mywidget w;
    w.show();
    return a.exec();
}
