# include <QLCDNumber>
# include <QSlider>
# include <QVBoxLayout>

# include "lcdrange.h"

LCDRange::LCDRange(QWidget* p):QWidget(p)
{
    QLCDNumber* lcd = new QLCDNumber(2);
    lcd->setSegmentStyle(QLCDNumber::Flat);

    sld = new QSlider(Qt::Horizontal);
    sld->setRange(0, 99);
    sld->setValue(0);

    connect (sld, SIGNAL(valueChanged(int)), lcd, SLOT(display(int)));
    connect (sld, SIGNAL(valueChanged(int)), this, SIGNAL(valueChanged(int)));  /* signal to signal connect */

    QVBoxLayout* box = new QVBoxLayout;
    box->addWidget(lcd);
    box->addWidget(sld);
    setLayout(box);
}


int
LCDRange::value() const
{
    return sld->value();
}

void
LCDRange::setValue(int v)
{
    sld->setValue(v);
}
