# include <QApplication>
# include <QPushButton>
# include <QFont>
# include <QWidget>
# include <QLCDNumber>
# include <QSlider>
# include <QVBoxLayout>

class mywidget:public QWidget
{
    public:
    mywidget (QWidget* parent=0);
};

mywidget::mywidget (QWidget* parent) : QWidget (parent)
{
    setFixedSize (200, 120);

    QPushButton* q = new QPushButton(tr("Quit"), this);
    q->setGeometry(10, 40, 180, 40);
    q->setFont(QFont("DejaVu Sans Mono", 14, QFont::Normal));

    QLCDNumber* lcd = new QLCDNumber(2);
    lcd->setSegmentStyle(QLCDNumber::Filled);
    
    QSlider* slider = new QSlider(Qt::Horizontal);
    slider->setRange(0, 99);
    slider->setValue (0);

    connect (q, SIGNAL(clicked()), qApp, SLOT(quit()));
    connect (slider, SIGNAL(valueChanged(int)), lcd, SLOT(display(int)));

    QVBoxLayout* lout = new QVBoxLayout; 
    lout->addWidget(q);
    lout->addWidget(slider);
    lout->addWidget(lcd);

    setLayout(lout);
}

int
main (int c, char**v)
{
    QApplication a (c, v);
    //QWidget w;
    mywidget w, w2;

    //w.resize (200, 120);

    //QPushButton b ("Quit", &w);          //w is parent.
    //b.setGeometry (10, 40, 180, 20);
    //b.setFont(QFont("Monospace", 24, QFont::Bold));

    //QObject::connect (&b, SIGNAL(clicked()), &a, SLOT(quit()));

    //b.show();
    w.show(); w2.show();
    return a.exec();
}

