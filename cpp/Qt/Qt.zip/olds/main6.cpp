# include <QApplication>
# include <QWidget>
# include <QFont>
# include <QLCDNumber>
# include <QSlider>
# include <QPushButton>
# include <QGridLayout>
# include <QVBoxLayout>

class LCDRange:public QWidget                //custom widget
{
    public:
        LCDRange (QWidget* parent = 0);
};

LCDRange::LCDRange (QWidget* parent) : QWidget (parent)       
{
    QLCDNumber* lcd = new QLCDNumber(4);
    lcd->setSegmentStyle(QLCDNumber::Flat);
    //lcd->setMode(QLCDNumber::Hex);
    //lcd->setBinMode();

    QSlider* sld = new QSlider (Qt::Horizontal);
    sld->setRange(0, 99);
    sld->setValue(0);

    connect (sld, SIGNAL(valueChanged(int)), lcd, SLOT(display(int)));

    QVBoxLayout* lyt = new QVBoxLayout;
    lyt->addWidget(lcd);
    lyt->addWidget(sld);
    setLayout(lyt);
}

class mywidget: public QWidget
{
    public:
        mywidget (QWidget* p=0);
};

mywidget::mywidget (QWidget* p) : QWidget (p)
{
    QPushButton* b = new QPushButton(tr("quit"));
    b -> setFont (QFont("DejaVu San mono", 14, QFont::Normal));
    connect (b, SIGNAL(clicked()), qApp, SLOT(quit()));

    QGridLayout* grid = new QGridLayout;
    for (int row=0; row<3; ++row)
    {
        for(int col=0; col < 3; ++col)
	{
	    LCDRange* lcd = new LCDRange();
	    grid->addWidget (lcd, row, col);
	}
    }

    QVBoxLayout* layout = new QVBoxLayout;
    layout->addWidget (b);
    layout->addLayout (grid);
    setLayout(layout);
}

int
main (int c, char** v)
{
    QApplication a(c, v);
    mywidget w;
    w.show();
    return a.exec();
}
