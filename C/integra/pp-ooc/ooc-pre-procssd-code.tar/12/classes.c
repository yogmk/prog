extern const void * al (void);
extern const void * ar (void);
extern const void * arClass (void);
extern const void * arm (void);
extern const void * ath (void);
extern const void * dd (void);
extern const void * ef (void);
extern const void * eserved (void);
extern const void * inary (void);
extern const void * inus (void);
extern const void * iv (void);
extern const void * lobal (void);
extern const void * nary (void);
extern const void * ode (void);
extern const void * odeClass (void);
extern const void * onad (void);
extern const void * onst (void);
extern const void * ser (void);
extern const void * ssign (void);
extern const void * ub (void);
extern const void * uiltin (void);
extern const void * ult (void);
extern const void * umber (void);
extern const void * un (void);
extern const void * yad (void);
extern const void * ymbol (void);
extern const void * ymtab (void);

const void * (* classes [])(void) = {
	al,
	ar,
	arClass,
	arm,
	ath,
	dd,
	ef,
	eserved,
	inary,
	inus,
	iv,
	lobal,
	nary,
	ode,
	odeClass,
	onad,
	onst,
	ser,
	ssign,
	ub,
	uiltin,
	ult,
	umber,
	un,
	yad,
	ymbol,
	ymtab,
0 };
