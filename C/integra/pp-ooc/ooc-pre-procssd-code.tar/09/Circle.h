# ifndef Circle_h
# define Circle_h

# include "Point.h"

extern const void * const Circle (void);

# endif
