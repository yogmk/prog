#ifndef	NEW_H
#define	NEW_H

void * new (const void * type, ...);
void delete (void * item);

#endif
