# ifndef Stack_h
# define Stack_h

# include "List.h"

extern const void * Stack;

void initStack (void);

# endif
