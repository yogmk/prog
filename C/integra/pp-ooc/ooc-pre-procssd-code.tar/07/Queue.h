# ifndef Queue_h
# define Queue_h

# include "List.h"

extern const void * Queue;

void initQueue (void);

# endif
