# ifndef Stack_r
# define Stack_r

# include "List.r"

struct Stack { const struct List _;
};

# endif
