# ifndef Circle_r
# define Circle_r

# include "Point.r"

struct Circle { const struct Point _;
	int rad;
};

# endif
