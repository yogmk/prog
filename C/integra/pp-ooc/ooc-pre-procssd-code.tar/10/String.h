# ifndef String_h
# define String_h

# include "Object.h"

extern const void * const String (void);

# endif
