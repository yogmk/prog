#ifndef	CIRCLE_R
#define	CIRCLE_R

#include "Point.r"

struct Circle { const struct Point _; int rad; };

#endif
